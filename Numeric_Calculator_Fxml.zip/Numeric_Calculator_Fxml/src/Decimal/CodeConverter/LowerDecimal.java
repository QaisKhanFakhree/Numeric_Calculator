/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Decimal.CodeConverter;



/**
 *
 * @author Qais Khan
 */
public class LowerDecimal {
    public static String Convert(long number,long base){
        long quotient=number/base;
        long remainder=number%base;
        
        if(quotient==0){
            return Long.toString(remainder);
        }else{
            return Convert(quotient,base)+Long.toString(remainder);
        }
        
    }
    
}
