/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Decimal.CodeConverter;

/**
 *
 * @author Qais Khan
 */
public class Code {
   public static long binToDec(String bin,int number){
        long dec=0L;long pow=1L;
        for(int i=(bin.length()-1);i>=0;i--){
            char c=bin.charAt(i);
            dec=dec+(Long.parseLong(c+"")*pow);
            pow=pow*number;
        }return dec;
    } 
   ///Start Code
   /*This two Method(BintoDec, Convert) Use Convert Binary
   to Ternery that first it Convert binary Number to Decimal and 
   then it Convert Decimal to Ternery*/
     public static long binToDec(String bin){
         /*This Method Convert Number from Binary to Decimal*/
        long dec=0L;long pow=1L;
        for(int i=(bin.length()-1);i>=0;i--){
            char c=bin.charAt(i);
            dec=dec+(Long.parseLong(c+"")*pow);
            pow=pow*2;
        }
        
        
        return dec;
    }
     public static String Convert(long number,long base){
         /*This Method Convert Decimal to Base*/
        long quotient=number/base;
        long remainder=number%base;
        
        if(quotient==0){
            return Long.toString(remainder);
        }else{
            return Convert(quotient,base)+Long.toString(remainder);
        }
        
    }///End Of Code
      public static String Converter(long d){
        String digits="0123456789A";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%11;
            hex=digits.charAt((int) digit)+hex;
            d=d/11;
        }
        return hex;
    }
     public static String Doudecimal(long d){
        String digits="0123456789AB";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%12;
            hex=digits.charAt((int) digit)+hex;
            d=d/12;
        }
        return hex;
    }
     public static String Tridecimal(long d){
        String digits="0123456789ABC";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%13;
            hex=digits.charAt((int) digit)+hex;
            d=d/13;
        }
        return hex;
    }
      public static String Tetradecimal(long d){
        String digits="0123456789ABCD";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%14;
            hex=digits.charAt((int) digit)+hex;
            d=d/14;
        }
        return hex;
    }
      public static String pentadecimal(long d){
        String digits="0123456789ABCDE";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%15;
            hex=digits.charAt((int) digit)+hex;
            d=d/15;
        }
        return hex;
    }
      public static String HexaDecimal(long d){
        String digits="0123456789ABCDEF";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%16;
            hex=digits.charAt((int) digit)+hex;
            d=d/16;
        }
        return hex;
    }
        public static long TerToDec(String bin){
        long dec=0L;long pow=1L;
        for(int i=(bin.length()-1);i>=0;i--){
            char c=bin.charAt(i);
            dec=dec+(Long.parseLong(c+"")*pow);
            pow=pow*3;
        }
        
        
        return dec;
    }
         public static long QUAToDec(String bin){
        long dec=0L;long pow=1L;
        for(int i=(bin.length()-1);i>=0;i--){
            char c=bin.charAt(i);
            dec=dec+(Long.parseLong(c+"")*pow);
            pow=pow*4;
        }
        
        
        return dec;
    }
       public static long Und2decimal(String s){
       String digit="0123456789A";
       s=s.toUpperCase();
       long val=0;
       for(int i=0;i<s.length();i++){
           char c=s.charAt(i);
           long d=digit.indexOf(c);
           val=11*val+d;
       }return val;
   }
       public static long Dou2decimal(String s){
       String digit="0123456789AB";
       s=s.toUpperCase();
       long val=0;
       for(int i=0;i<s.length();i++){
           char c=s.charAt(i);
           long d=digit.indexOf(c);
           val=12*val+d;
       }return val;
       }
       
       public static long Tri2decimal(String s){
       String digit="0123456789ABC";
       s=s.toUpperCase();
       long val=0;
       for(int i=0;i<s.length();i++){
           char c=s.charAt(i);
           long d=digit.indexOf(c);
           val=13*val+d;
       }return val;
       }
       public static long Tet2decimal(String s){
       String digit="0123456789ABCD";
       s=s.toUpperCase();
       long val=0;
       for(int i=0;i<s.length();i++){
           char c=s.charAt(i);
           long d=digit.indexOf(c);
           val=14*val+d;
       }return val;
       }
       public static long Penta2decimal(String s){
       String digit="0123456789ABCDE";
       s=s.toUpperCase();
       long val=0;
       for(int i=0;i<s.length();i++){
           char c=s.charAt(i);
           long d=digit.indexOf(c);
           val=15*val+d;
       }return val;
       }
       
       public static long Hexa2decimal(String s){
       String digit="0123456789ABCDEF";
       s=s.toUpperCase();
       long val=0;
       for(int i=0;i<s.length();i++){
           char c=s.charAt(i);
           long d=digit.indexOf(c);
           val=16*val+d;
       }return val;
       }
    
    
}
