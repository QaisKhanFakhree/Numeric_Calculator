/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Decimal.CodeConverter;



/**
 *
 * @author Qais Khan
 */
public class UpperDecimal {
    public static String Converter(long d){
        String digits="0123456789A";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%11;
            hex=digits.charAt((int) digit)+hex;
            d=d/11;
        }
        return hex;
    }
     public static String Doudecimal(long d){
        String digits="0123456789AB";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%12;
            hex=digits.charAt((int) digit)+hex;
            d=d/12;
        }
        return hex;
    }
     public static String Tridecimal(long d){
        String digits="0123456789ABC";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%13;
            hex=digits.charAt((int) digit)+hex;
            d=d/13;
        }
        return hex;
    }
      public static String Tetradecimal(long d){
        String digits="0123456789ABCD";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%14;
            hex=digits.charAt((int) digit)+hex;
            d=d/14;
        }
        return hex;
    }
      public static String pentadecimal(long d){
        String digits="0123456789ABCDE";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%15;
            hex=digits.charAt((int) digit)+hex;
            d=d/15;
        }
        return hex;
    }
      public static String HexaDecimal(long d){
        String digits="0123456789ABCDEF";
        if(d==0)return "0";
        String hex="";
        while(d>0){
           long digit=d%16;
            hex=digits.charAt((int) digit)+hex;
            d=d/16;
        }
        return hex;
    }
}
