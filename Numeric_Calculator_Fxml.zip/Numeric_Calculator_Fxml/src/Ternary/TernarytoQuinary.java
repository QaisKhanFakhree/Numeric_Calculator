/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Ternary;

import Decimal.CodeConverter.Code;
import Others.NColor;
import Tools.NButton;
import Tools.NLabel;
import Tools.NStackPane;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

/**
 *
 * @author Qais Khan
 */
public class TernarytoQuinary {
   private static String value="";
    
    public static Node AllComponent(){
        AnchorPane anchor=new AnchorPane();
        
        Pane pane=new Pane(); 
        pane.setPrefHeight(3);
        pane.setPrefWidth(604);
        pane.setLayoutX(0);pane.setLayoutY(0);
        pane.setStyle("-fx-background-color:#ffffff");
        
        Label title=NLabel.nLabel("Converting Ternery to Quinary : ", 38, 37, 30, 520);
        title.setFont(new Font(30));title.setTextFill(NColor.WHITE);
        
        StackPane stackpane=NStackPane.Stack(560, 101, 21, 112);
        Label lab=NLabel.nLabel("0", 0, 0,39, 552);
        lab.setFont(Font.font("Britannic Bold",20));
        stackpane.getChildren().add(lab);
        lab.setTextFill(NColor.BLACK);
        
        Label use=NLabel.nLabel("Use Number Keyboard", 119, 260, 40, 300);
        use.setTextFill(NColor.WHITE);
        use.setFont(new Font(20));
        
         DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(5.0);
        dropShadow.setOffsetX(3.0);
        dropShadow.setOffsetY(3.0);
        dropShadow.setColor(NColor.BLACK);  
        
        Button zero=NButton.MButton("0", 119, 300, "WHITE",1, 100, 33);
        zero.setFont(Font.font("Baskerville Old Face", 15));
        zero.setTextFill(NColor.WHITE);
        zero.setOnAction(N->{
        value=value+"0";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button one=NButton.MButton("1", 235, 300, "WHITE",1, 100, 33);
        one.setFont(Font.font("Baskerville Old Face", 15));
        one.setTextFill(NColor.WHITE);
        one.setOnAction(N->{
        value=value+"1";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button two=NButton.MButton("2", 350, 300, "WHITE",1, 100, 33);
        two.setTextFill(NColor.WHITE);
        two.setFont(Font.font("Baskerville Old Face", 15));
        two.setOnAction(N->{
        value=value+"2";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button back=NButton.MButton("Back", 130, 350, "WHITE",1, 150, 33);
        back.setFont(Font.font("Baskerville Old Face", 15));
        back.setTextFill(NColor.WHITE);
        back.setOnAction(N->{
        value=value.substring(0,value.length()-1);
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button convert=NButton.MButton("Convert", 300, 350, "WHITE",1, 150, 33);
        convert.setFont(Font.font("Baskerville Old Face", 15));
        convert.setTextFill(NColor.WHITE);
        convert.setOnAction(N->{
        lab.setTextFill(NColor.DARKGREEAN);
        lab.setText(Code.Convert(Code.TerToDec(value), 5));
        value="";
        });
        
        Group ButtonS=new Group();
        ButtonS.getChildren().addAll(zero,one,two,back,convert);
        ButtonS.setEffect(dropShadow);
        
        /*Pane use as a Line for Right Side of Button Just for Design with White Color*/
        Pane right=new Pane();
        right.setLayoutX(97);
        right.setLayoutY(254);
        right.setPrefWidth(1);
        right.setPrefHeight(212);
        right.setStyle("-fx-background-color:#ffffff;");
        
        /*Pane use as a Line for Bottom of Button Just for Disign with White Color*/
        Pane bottom=new Pane();
        bottom.setLayoutX(114);
        bottom.setLayoutY(502);
        bottom.setPrefWidth(336);
        bottom.setPrefHeight(2);
        bottom.setStyle("-fx-background-color:#ffffff;");
        
        /*Use Pane as A Line for Left for design with with Color With White Color*/
         Pane left=new Pane();
        left.setLayoutX(463);
        left.setLayoutY(255);
        left.setPrefWidth(1);
        left.setPrefHeight(212);
        left.setStyle("-fx-background-color:#ffffff;");
        
        /*Pane use as a Line for Above of Button Just for Disign with White Color*/
        Pane above=new Pane();
        above.setLayoutX(114);
        above.setLayoutY(250);
        above.setPrefWidth(336);
        above.setPrefHeight(2);
        above.setStyle("-fx-background-color:#ffffff;");
        
        Group panes=new Group();
        panes.getChildren().addAll(right,bottom,left,above);
        panes.setEffect(dropShadow);
        
        Label base=NLabel.nLabel("Base 3 to Base 5", 45, 540, 40, 250);
        base.setFont(Font.font("Baskerville Old Face", 15));
        base.setStyle("-fx-background-color:#00FFFF");
        
        Label infor=NLabel.nLabel("Information", 30, 500, 40, 150);
        infor.setFont(Font.font("Baskerville Old Face", 20));
        infor.setTextFill(NColor.AQUA);
        
        
        
        anchor.getChildren().addAll(pane,title,infor,base,stackpane,use,panes,ButtonS);
        
        return anchor;
    }
       
}
