/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Tridecimal;

import Decimal.CodeConverter.Code;
import Others.NColor;
import Tools.NButton;
import Tools.NLabel;
import Tools.NPane;
import Tools.NStackPane;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

/**
 *
 * @author Qais Khan
 */
public class TridecimaltoDoudecimal {
     private static String value="";
    public static Node All(){
        /*Make AnchorPane as Parent*/
        AnchorPane parent=new AnchorPane();
        
        Pane separter=new Pane();
        separter.setPrefWidth(604);
        separter.setPrefHeight(3);
        separter.setLayoutX(0);separter.setLayoutY(0);
        separter.setTranslateX(0);separter.setTranslateY(0);separter.setTranslateZ(0);
        separter.setScaleX(1);separter.setScaleY(1);separter.setScaleZ(1);
        separter.setStyle("-fx-background-color:#ffffff");
        
        Label title=NLabel.nLabel("Converting Tridecimal to Duodecimal : ", 38,37, 30, 550);
        title.setTextFill(NColor.WHITE);
        title.setFont(new Font(30));
        
        
         StackPane stack=NStackPane.Stack(560, 101, 21, 112);
         Label lab=NLabel.nLabel("0", 0, 0, 39, 552);
         lab.setFont(Font.font("Britannic Bold", 20));
         stack.getChildren().add(lab);
          lab.setTextFill(NColor.BLACK);
         
         
        Button zero=NButton.MButton("0", 119, 300, "WHITE", 1, 67, 33);
        zero.setFont(Font.font("Baskerville Old Face", 15));
        zero.setTextFill(NColor.WHITE);
        zero.setOnAction(e->{value=value+"0";
        lab.setText(value);
        });
        Button one=NButton.MButton("1", 200, 300, "WHITE", 1, 67, 33);
        one.setFont(Font.font("Baskerville Old Face", 15));
        one.setTextFill(NColor.WHITE);
        one.setOnAction(e->{value=value+"1";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button two=NButton.MButton("2", 288, 300, "WHITE", 1, 67, 33);
        two.setFont(Font.font("Baskerville Old Face", 15));
        two.setTextFill(NColor.WHITE);
        two.setOnAction(e->{value=value+"2";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button three=NButton.MButton("3", 377, 300, "WHITE", 1, 67, 33);
        three.setFont(Font.font("Baskerville Old Face", 15));
        three.setTextFill(NColor.WHITE);
        three.setOnAction(e->{value=value+"3";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button four=NButton.MButton("4", 119, 352, "WHITE", 1, 67, 33);
        four.setFont(Font.font("Baskerville Old Face", 15));
        four.setTextFill(NColor.WHITE);
        four.setOnAction(e->{value=value+"4";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button five=NButton.MButton("5", 201, 352, "WHITE", 1, 67, 33);
        five.setFont(Font.font("Baskerville Old Face", 15));
        five.setTextFill(NColor.WHITE);
        five.setOnAction(e->{value=value+"5";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button six=NButton.MButton("6", 288, 352, "WHITE", 1, 67, 33);
        six.setFont(Font.font("Baskerville Old Face", 15));
        six.setTextFill(NColor.WHITE);
        six.setOnAction(e->{value=value+"6";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button seven=NButton.MButton("7", 376, 352, "WHITE", 1, 67, 33);
        seven.setFont(Font.font("Baskerville Old Face", 15));
        seven.setTextFill(NColor.WHITE);
        seven.setOnAction(e->{value=value+"7";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button eight=NButton.MButton("8", 119, 400, "WHITE", 1, 67, 33);
        eight.setFont(Font.font("Baskerville Old Face", 15));
        eight.setTextFill(NColor.WHITE);
        eight.setOnAction(e->{value=value+"8";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
       
        Button nine=NButton.MButton("9", 200, 400, "WHITE", 1, 67, 33);
        nine.setFont(Font.font("Baskerville Old Face", 15));
        nine.setTextFill(NColor.WHITE);/*Text Color of Button*/
        nine.setOnAction(e->{value=value+"9";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button A=NButton.MButton("A", 287, 400, "WHITE", 1, 67, 33);
        A.setFont(Font.font("Baskerville Old Face", 15));
        A.setTextFill(NColor.WHITE);/*Text Color of Button*/
        A.setOnAction(e->{value=value+"A";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button B=NButton.MButton("B", 376, 400, "WHITE", 1, 67, 33);
        B.setFont(Font.font("Baskerville Old Face", 15));
        B.setTextFill(NColor.WHITE);/*Text Color of Button*/
        B.setOnAction(e->{value=value+"B";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button C=NButton.MButton("B", 119, 450, "WHITE", 1, 67, 33);
        C.setFont(Font.font("Baskerville Old Face", 15));
        C.setTextFill(NColor.WHITE);/*Text Color of Button*/
        C.setOnAction(e->{value=value+"C";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button back=NButton.MButton("Back", 235, 451, "WHITE", 1, 67, 33);
        back.setFont(Font.font("Baskerville Old Face", 15));
        back.setTextFill(NColor.WHITE);
        back.setOnAction(e->{
            try{
        value=value.substring(0, value.length()-1);
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        if(value.equals("")){
            lab.setText("0");
        }
            }catch(StringIndexOutOfBoundsException ea){
                
            }
        });
        
        Button convert=NButton.MButton("Convert", 376, 451, "WHITE", 1,67, 33);
        convert.setFont(Font.font("Baskerville Old Face", 15));
        convert.setTextFill(NColor.WHITE);
        convert.setOnAction(e->{
        lab.setText(Code.Doudecimal(Code.Tri2decimal(value)));
        lab.setTextFill(NColor.DARKGREEAN);
        value="";
        });
        
        
        
        
        
        Label use=NLabel.nLabel("Use Number KeyBroad", 119, 260, 40, 300);
        use.setTextFill(NColor.WHITE);
        use.setFont(new Font(20));
        
        DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(5.0);
        dropShadow.setOffsetX(3.0);
        dropShadow.setOffsetY(3.0);
        dropShadow.setColor(NColor.BLACK);  
        
        Pane right=NPane.pane(1, 212, 97, 254);
        Pane bottom=NPane.pane(336,2, 114, 502);
        Pane left=NPane.pane(1, 212, 463, 255);
        Pane above=NPane.pane(336,2, 114, 250);
        
        Label base=NLabel.nLabel("Base 13 to Base 12", 45, 540, 40, 250);
        base.setFont(Font.font("Baskerville Old Face", 15));
        base.setStyle("-fx-background-color:#00FFFF");
        
        Label infor=NLabel.nLabel("Information", 30, 500, 40, 150);
        infor.setFont(Font.font("Baskerville Old Face", 20));
        infor.setTextFill(NColor.AQUA);
        
        Group Gbutton=new Group();
        Gbutton.getChildren().addAll(zero,one,eight,C,B,seven,nine,six,A,five,four,three,two,back,convert);
        
        Group pane=new Group();
        pane.getChildren().addAll(right,bottom,left,above);
        pane.setEffect(dropShadow);
        
        
        parent.getChildren().addAll(separter,base,
                infor,title,stack,Gbutton,pane,use
        );
        
        return parent;
    
    }  
}
