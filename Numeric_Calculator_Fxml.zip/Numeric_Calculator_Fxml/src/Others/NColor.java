/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Others;

import javafx.scene.paint.Color;

/**
 *
 * @author Qaisfakhree
 */
public class NColor {
    public static final Color STAGE =Color.rgb(37, 80, 80);
    public static final Color WHITE=Color.rgb(255, 255, 255);
    public static final Color BLACK=Color.rgb(0, 0, 0);
    public static final Color LINE=Color.rgb(122, 37, 37);
    public static final Color DARKGREEAN=Color.rgb(100, 143, 100);
    public static final Color AQUA=Color.rgb(0, 255, 255);
}
