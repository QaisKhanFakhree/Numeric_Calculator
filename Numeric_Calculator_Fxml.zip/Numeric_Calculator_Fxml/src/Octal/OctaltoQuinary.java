/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Octal;

import Decimal.CodeConverter.Code;
import Others.NColor;
import Tools.NButton;
import Tools.NLabel;
import Tools.NPane;
import Tools.NStackPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

/**
 *
 * @author Qais Khan
 */
public class OctaltoQuinary {
        private static String value="";
   public static Node AllComponent(){
       AnchorPane anchorPane=new AnchorPane();
       
        Pane separter=NPane.pane(604,3,0,0);
       
        Label title=NLabel.nLabel("Converting Octal to Quinary :",38,37,30,520);
        title.setTextFill(NColor.WHITE);
        title.setFont(new Font(30));
       
        
        StackPane stackpane=NStackPane.Stack(560,101,21,119);
        Label lab=NLabel.nLabel("0",0,0,39,552);
         lab.setFont(Font.font("Britannic Bold",20));
        lab.setTextFill(NColor.BLACK);
        stackpane.getChildren().add(lab);
       
       Label user=NLabel.nLabel("Use Number Keybroad",119,260,40,300);
        user.setTextFill(NColor.WHITE);
        user.setFont(new Font(20));
        
        Button zero=NButton.MButton("0",119,300,"WHITE",1,100, 33);
        zero.setFont(Font.font("Baskerville Old Face",15));
        zero.setTextFill(NColor.WHITE);
        zero.setOnAction(N->{
        value=value+"0";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button one=NButton.MButton("1",235, 300,"WHITE",1,100, 33);
        one.setFont(Font.font("Baskerville Old Face",15));
        one.setTextFill(NColor.WHITE);
        one.setOnAction(N->{
        value=value+1;
        lab.setText(value);
        lab.setTextFill(NColor.BLACK);
        });
        
        Button two=NButton.MButton("2",350,300,"WHITE",1,100,33);
        two.setFont(Font.font("Baskerville Old Face",15));
        two.setTextFill(NColor.WHITE);
        two.setOnAction(N->{
        value=value+2;
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button three=NButton.MButton("3",119,350,"WHITE",1,100, 33);
        three.setFont(Font.font("Baskerville Old Face",15));
        three.setTextFill(NColor.WHITE);
        three.setOnAction(N->{
        value=value+3;
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button four=NButton.MButton("4",235,350,"WHITE",1,100,33);
        four.setFont(Font.font("Baskerville Old Face", 15));
        four.setTextFill(NColor.WHITE);
        four.setOnAction(N->{
        value=value+4;
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button five=NButton.MButton("5",350,350,"WHITE",1,100,33);
        five.setFont(Font.font("Baskerville Old Face",15));
        five.setTextFill(NColor.WHITE);
        five.setOnAction(new EventHandler<ActionEvent>() {

           public void handle(ActionEvent N) {
               value=value+"5";
               lab.setTextFill(NColor.BLACK);
               lab.setText(value);
           }
       });
        
        Button six=NButton.MButton("6",119,400,"WHITE",1,100,33);
        six.setFont(Font.font("Baskerville Old Face",15));
        six.setTextFill(NColor.WHITE);
        six.setOnAction(new EventHandler<ActionEvent>() {

           public void handle(ActionEvent N) {
               value=value+"6";
               lab.setTextFill(NColor.BLACK);
               lab.setText(value);
           }
       });
       
        Button seven=NButton.MButton("7",235,400,"WHITE",1,100,33);
        seven.setFont(Font.font("Baskerville Old Face",15));
        seven.setTextFill(NColor.WHITE);
        seven.setOnAction(new EventHandler<ActionEvent>() {

           public void handle(ActionEvent N) {
               value=value+"7";
               lab.setTextFill(NColor.BLACK);
               lab.setText(value);
           }
       });
        
        Button back=NButton.MButton("Back",350, 400,"WHITE",1,100,33);
        back.setFont(Font.font("Baskerville Old Face",15));
        back.setTextFill(NColor.WHITE);
        back.setOnAction(new EventHandler<ActionEvent>() {

           public void handle(ActionEvent N) {
               value=value.substring(0,value.length()-1);
               lab.setTextFill(NColor.BLACK);
               lab.setText(value);
           }
       });
        
        Button convert=NButton.MButton("Convert",119,450,"WHITE",1,100,33);
        convert.setFont(Font.font("Baskerville Old Face",15));
        convert.setTextFill(NColor.WHITE);
        convert.setOnAction(new EventHandler<ActionEvent>() {

           public void handle(ActionEvent N) {
               lab.setTextFill(NColor.DARKGREEAN);
               lab.setText(Code.Convert(Code.binToDec(value,8),5));
               value="";
           }
       });
        
        Pane right=NPane.pane(1, 212, 97, 254);
        Pane bottom=NPane.pane(336,2, 114, 502);
        Pane left=NPane.pane(1, 212, 463, 255);
        Pane above=NPane.pane(336,2, 114, 250);
     
        Label base=NLabel.nLabel("Base 8 to Base 5", 45, 540, 40, 250);
        base.setFont(Font.font("Baskerville Old Face", 15));
        base.setStyle("-fx-background-color:#00FFFF");
        
        Label infor=NLabel.nLabel("Information", 30, 500, 40, 150);
        infor.setFont(Font.font("Baskerville Old Face", 20));
        infor.setTextFill(NColor.AQUA);
        
        DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(5.0);
        dropShadow.setOffsetX(3.0);
        dropShadow.setOffsetY(3.0);
        dropShadow.setColor(NColor.BLACK); 
     
        Group Groupp=new Group();
        Groupp.getChildren().addAll(left,right,bottom,above);
        Groupp.setEffect(dropShadow);
     
        Group button=new Group();
        button.getChildren().addAll(one,two,zero,three,four,seven,six,five,back,convert);
        
       
       
       
      anchorPane.getChildren().addAll(separter,title,infor,base,stackpane,user,button,Groupp);
       return anchorPane;
   }  
}
