/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeric_calculator_fxml;

import Binary.*;
import Decimal.*;
import Others.NColor;
import Quaternary.*;
import Quinary.*;

import Senary.*;


import Ternary.TernarytoQuaternary;
import Ternary.TernarytoQuinary;

import Tools.NButton;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXRadioButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;



/**
 *
 * @author Qaisfakhree
 */
public class Controller implements Initializable {
    
    @FXML private AnchorPane Menu,BintoDic;
   
    @FXML private ToggleGroup From;
    
    @FXML private ToggleGroup To;

    @FXML private JFXRadioButton FDecimal,FBinary,FTernary,FQuaternary
            ,FSenary,FQuinary,FSeptenary,FOctal,FUndecimal,FNonary
            ,FDoudecimal,FTridecimal,FTetradecimal,FPentadecimal,FHexadecimal;
    
    @FXML private JFXRadioButton TBinary,TQuaternary,TTernary,TQuinary
            ,TSenary,TSeptenary,TOctal,TNonary,TDecimal,TTridecimal
            ,TUndecimal,TDuodecimal,TTetradecimal,TPentadecimal,THexadecimal;
    
    @FXML private JFXButton NextA;

    @FXML private Label lab;
     
    @Override public void initialize(URL url, ResourceBundle rb) {
       
    }
    
    /*Method Next for RadioButton of that can Change scene or Anchor*/
   @FXML public void Next(ActionEvent event) {
       
       Button backtoMenu=NButton.MButton("Back To Menu", 430, 540, "AQUA",2, 120, 25);
        backtoMenu.setFont(Font.font("Baskerville Old Face", 15));
        backtoMenu.setTextFill(NColor.AQUA);
        backtoMenu.setOnAction(e->{String value="";
        Menu.toFront();
        });
        
        
        
        
       
        if(FDecimal.isSelected()&&TBinary.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimalToBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                }
            });
            
        }else if(FDecimal.isSelected()&&TTernary.isSelected()){
             NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimaltoTernery.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        }else if(FDecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            }); 
        }else if(FDecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            }); 
        }else if(FDecimal.isSelected()&&TSenary.isSelected()){
             NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        }else if(FDecimal.isSelected()&&TOctal.isSelected()){
             NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        }else if(FDecimal.isSelected()&&TSeptenary.isSelected()){
             NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=DecimaltoSeptenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        }else if(FDecimal.isSelected()&&TNonary.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FDecimal.isSelected()&&TUndecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoUndecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FDecimal.isSelected()&&TDecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FDecimal.isSelected()&&TDuodecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FDecimal.isSelected()&&TTridecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FDecimal.isSelected()&&TTetradecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoTetradecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        
        }else if(FDecimal.isSelected()&&TPentadecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoPentadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FDecimal.isSelected()&&THexadecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                 BintoDic.getChildren().clear();
                    Node all=DecimaltoHexdecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();   
                }
            });
        }else if(FBinary.isSelected()&&TDecimal.isSelected()){
            NextA.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent E) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoDecimal.AllNode();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                    
                    
                   
                    
                }
            });
       }else if(FBinary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoTernery.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoQuaternray.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }
        else if(FBinary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        
    
    }else if(FBinary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FBinary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoDuodecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FBinary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FBinary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FBinary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FBinary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=BinarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoTernery.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoDoudecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuaternary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuaternarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoTernary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoDoudecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FQuinary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=QuinarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoTernary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoDuodecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSenary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=SenarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoTernary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoDuodecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FSeptenary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Septenary.SeptenarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoTernary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoDuodecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FOctal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Octal.OctaltoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernerytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=TernarytoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=TernarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernerytoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoTernary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoDoudecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTernary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Ternary.TernarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoBinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoTernary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoQuaternary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoQuinary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoSenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoSeptenary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoOctal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoNonary.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoDecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoUndecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoDuodecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoTridecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoTetradecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoPentadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FNonary.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Nonary.NonarytoHexadecimal.AllComponent();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }
    else if(FUndecimal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoTernary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }
    else if(FUndecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoSeptenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoUndecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoTetradecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoPentadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FUndecimal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Undecimal.UndecimaltoHexadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoTernary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoSeptenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoUndecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoTetradecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoPentadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FDoudecimal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Doudecimal.DoudecimaltoHexadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoTernary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoSeptenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoUndecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoTetradecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoPentadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoHexadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTridecimal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tridecimal.TridecimaltoHexadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoTernary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoSeptenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoUndeimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoTetradecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoPentadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FTetradecimal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Tetradecimal.TetradecimaltoHexadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
        }else if(FPentadecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoTernery.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoSeptenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoUndecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TTetradecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoTetradecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&TPentadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoPantadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FPentadecimal.isSelected()&&THexadecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Pentadecimal.PentadecimaltoHexadecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TBinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoBinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TTernary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoTernary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TQuaternary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoQuaternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TQuinary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoQuinary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TSenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoSenary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TSeptenary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoSepternary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TOctal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoOctal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TNonary.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoNonary.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TDecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoDecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TUndecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoUndecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TDuodecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoDoudecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else if(FHexadecimal.isSelected()&&TTridecimal.isSelected()){
           NextA.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    BintoDic.getChildren().clear();
                    Node all=Hexadecimal.HexadecimaltoTridecimal.All();
                    BintoDic.getChildren().addAll(all,backtoMenu);
                    BintoDic.toFront();
                    Menu.toBack();
                }
            });
    }else{
    
    }
        
   }
   
   /*Method for PowerOff or Close Button that can Close all the Program*/
   @FXML public void PowerOff(ActionEvent event) {
     System.exit(0);
    }
    
   
      
    
}
