/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Tools;

import javafx.scene.layout.Pane;

/**
 *
 * @author Qais Khan
 */
public class NPane {
    public static Pane pane(int prefWidth,int prefHeight,int luyoutx,int luyouty){
        Pane pane=new Pane();
        pane.setPrefSize(prefWidth, prefHeight);
        pane.setLayoutX(luyoutx);
        pane.setLayoutY(luyouty);
        pane.setStyle("-fx-background-color:#ffffff");
        return pane;
    }
}
