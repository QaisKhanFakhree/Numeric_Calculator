/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;

import javafx.scene.control.Label;

/**
 *
 * @author Qaisfakhree
 */
public class NLabel {
    public static Label nLabel(String message,float x,float y,float height,float width){
        Label lab=new Label();
        
        lab.setText(message);
        lab.setLayoutX(x);
        lab.setLayoutY(y);
        lab.setPrefSize(width, height);
        lab.setScaleX(1);lab.setScaleY(1);lab.setScaleZ(1);
        lab.setTranslateX(0);lab.setTranslateY(0);lab.setTranslateZ(0);
       
        return lab;
    }
}
