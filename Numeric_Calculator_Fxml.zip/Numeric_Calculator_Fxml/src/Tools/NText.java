/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 *
 * @author Qaisfakhree
 */
public class NText {
    public static Text text(int layoutx,int layouty,Color m,String name){
        Text text=new Text();
        text.setLayoutX(layoutx);
        text.setLayoutY(layouty);
        text.setFill(m);
        text.setFont(Font.font("MV Boli", 19));
        text.setText(name);
        text.setVisible(true);
        text.setX(0);
        text.setY(0);
        ;
        
        
        return text;
    }
}
