/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;


import javafx.scene.layout.StackPane;

/**
 *
 * @author Qaisfakhree
 */
public class NStackPane {
    public static StackPane Stack(int width,int height,int layoutx,int layouty){
        
        StackPane stack=new StackPane();
        stack.setPrefWidth(width);
        stack.setPrefHeight(height);
        stack.setLayoutX(layoutx);
        stack.setLayoutY(layouty);
        stack.setStyle(""
                + "-fx-background-color:#ffffff;"
                + "-fx-border-color:#000000;"
                + "-fx-border-radius:1em;"
                + "-fx-background-radius:1em;");
       
        
        
        
        return stack;
    }
}
