/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;

import Others.NColor;
import com.jfoenix.controls.JFXButton;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.text.TextAlignment;

/**
 *
 * @author Qaisfakhree
 */
public class NButton extends JFXButton {
    
    public static Button MButton(String Name,double x,double y,String Color,double radius,double width,double height){
      JFXButton button =new JFXButton();
      button.setStyle("-fx-border-color:"+Color+";-fx-border-radius:"+radius+"em");
      button.setLayoutX(x);
      button.setLayoutY(y);
      button.setPrefSize(width,height);
      button.setText(Name);
      button.setTranslateZ(0);
      button.setTranslateY(0);
      button.setTranslateX(0);
      button.setScaleX(1);
      button.setScaleY(1);
      button.setScaleZ(1);
      button.setTextAlignment(TextAlignment.LEFT);
      button.setAlignment(Pos.CENTER);
     
   
      
       
       return button;
       
    }
}
