/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 */

package Binary;

import Decimal.CodeConverter.Code;
import Others.NColor;
import Tools.NButton;
import Tools.NLabel;
import Tools.NPane;
import Tools.NStackPane;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

/**
 *
 * @author Qais Khan
 * 
 **/
public class BinarytoTernery {
    private static String value="";
    public static Node AllComponent(){
        AnchorPane anchor=new AnchorPane();
        
//Seperter Use As a line that can Separate Menu from Anchor
        Pane seperter=NPane.pane(604, 3, 0, 0);
        
//Label for Title         
        Label title=NLabel.nLabel("Converting From Binary to Ter"
                + "nary : ", 38, 37, 30,520);
        title.setTextFill(NColor.WHITE);
        title.setFont(new Font(30));
        
//StackPane stack         
        StackPane stack=NStackPane.Stack(560,101, 21, 112);
        Label lab=NLabel.nLabel("0", 0, 0, 39, 552);
        lab.setFont(Font.font("Britannic Bold", 20));
        stack.getChildren().add(lab);

//Label User
        Label user=NLabel.nLabel("Use Number Keybroad", 119,260,40, 300);
        user.setTextFill(NColor.WHITE);
        user.setFont(new Font(20));
//Button Zero    
        Button zero=NButton.MButton("0", 119, 300,"WHITE", 1, 100,33);
        zero.setFont(Font.font("Baskerville Old Face",15));
        zero.setTextFill(NColor.WHITE);
        zero.setOnAction(E->{
        value=value+"0";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
//Button One       
        Button one=NButton.MButton("1", 235, 300, "WHITE",1, 100, 33);
        one.setFont(Font.font("Baskerville Old Face", 15));
        one.setTextFill(NColor.WHITE);
        one.setOnAction(w->{
        value=value+"1";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
//Button Back     
        Button back=NButton.MButton("Back", 347, 300, "WHITE", 1, 100, 33);
        back.setFont(Font.font("Baskerville Old Face", 15));
        back.setTextFill(NColor.WHITE);
        back.setOnAction(e->{
            try{
            value=value.substring(0,value.length()-1);
            }catch(StringIndexOutOfBoundsException ea){
           
                    }
        lab.setText(value);
        });
        
//Convert Button     
        Button convert=NButton.MButton("Convert", 200, 350, "WHITE",1, 200, 35);
        convert.setTextFill(NColor.WHITE);
        convert.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e) {
                lab.setTextFill(NColor.DARKGREEAN);
               lab.setText(""+Code.Convert(Code.binToDec(value), 3));
               value="";
            }
        });
        
//DropShadow     
        DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(5.0);
        dropShadow.setOffsetX(3.0);
        dropShadow.setOffsetY(3.0);
        dropShadow.setColor(NColor.BLACK);
        
//Group for Button       
        Group Gbutton=new Group();
        Gbutton.getChildren().addAll(zero,one,back,convert);
        Gbutton.setEffect(dropShadow);
        
//Group For Pane    
        Pane right=NPane.pane(1, 212,97,255);
        Pane left=NPane.pane(1,212,463,255);
        Pane above=NPane.pane(336,2,114, 250);
        Pane bottom=NPane.pane(336,2,114, 502);
        
        Label base=NLabel.nLabel("Base 2 to Base 3", 45, 540, 40, 250);
        base.setFont(Font.font("Baskerville Old Face", 15));
        base.setStyle("-fx-background-color:#00FFFF");
        
        Label infor=NLabel.nLabel("Information", 30, 500, 40, 150);
        infor.setFont(Font.font("Baskerville Old Face", 20));
        infor.setTextFill(NColor.AQUA);
        
        Group pane=new Group();
        pane.getChildren().addAll(right,left,bottom,above);
        pane.setEffect(dropShadow);
        
        
        anchor.getChildren().addAll(seperter,title,infor,base,user,stack,Gbutton,pane);
        return anchor;
        
    }
}
