/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Binary;

import Decimal.CodeConverter.Code;
import Others.NColor;
import Tools.NButton;
import Tools.NLabel;
import Tools.NStackPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

/**
 *
 * @author Qais Khan
 */
public class BinarytoDecimal {
    private static String value="";
    public static Node AllNode(){
        AnchorPane anchor=new AnchorPane();
        
        Pane separter=new Pane();
        separter.setPrefWidth(604);
        separter.setPrefHeight(3);
        separter.setLayoutX(0);separter.setLayoutY(0);
        separter.setTranslateX(0);separter.setTranslateY(0);separter.setTranslateZ(0);
        separter.setScaleX(1);separter.setScaleY(1);separter.setScaleZ(1);
        separter.setStyle("-fx-background-color:#ffffff");
        
         Label title=NLabel.nLabel("Converting From Binary to Decimal: ", 38,37, 30, 520);
        title.setTextFill(NColor.WHITE);
        title.setFont(new Font(30));
        
        
         StackPane stack=NStackPane.Stack(560, 101, 21, 112);
         Label lab=NLabel.nLabel("0", 0, 0, 39, 552);
         lab.setFont(Font.font("Britannic Bold", 20));
         stack.getChildren().add(lab);
          lab.setTextFill(NColor.BLACK);
          
          Label use=NLabel.nLabel("Use Numberic KeyBroad", 119, 260, 40, 300);
        use.setTextFill(NColor.WHITE);
        use.setFont(new Font(20));
        
        Button zero=NButton.MButton("Zero", 119, 300, "WHITE", 1, 100, 33);
        zero.setFont(Font.font("Baskerville Old Face", 15));
        zero.setTextFill(NColor.WHITE);
        zero.setOnAction(e->{value=value+"0";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button one=NButton.MButton("One", 235, 300, "WHITE", 1, 100, 33);
        one.setFont(Font.font("Baskerville Old Face", 15));
        one.setTextFill(NColor.WHITE);
        one.setOnAction(e->{value=value+"1";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button back=NButton.MButton("Back", 347, 300, "WHITE", 1, 100, 33);
        back.setFont(Font.font("Baskerville Old Face", 15));
        back.setTextFill(NColor.WHITE);
        back.setOnAction(e->{
            try{
            value=value.substring(0,value.length()-1);
            }catch(StringIndexOutOfBoundsException ea){
               lab.setText("0");
                    }
        lab.setText(value);
        });
        
        Button convert=NButton.MButton("Convert", 200, 350, "WHITE",1, 200, 35);
        convert.setTextFill(NColor.WHITE);
        convert.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {
                lab.setTextFill(NColor.DARKGREEAN);
               lab.setText(""+Code.binToDec(value, 2));
               value="";
            }
        });
        
        
        
        
        
        
        DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(5.0);
        dropShadow.setOffsetX(3.0);
        dropShadow.setOffsetY(3.0);
        dropShadow.setColor(NColor.BLACK);
        
        Group button=new Group(zero,one,back,convert);
        button.setEffect(dropShadow);
          
        
        /*Pane use as a Line for Right Side of Button Just for Design with White Color*/
        Pane right=new Pane();
        right.setLayoutX(97);
        right.setLayoutY(254);
        right.setPrefWidth(1);
        right.setPrefHeight(212);
        right.setStyle("-fx-background-color:#ffffff;");
        
        /*Pane use as a Line for Bottom of Button Just for Disign with White Color*/
        Pane bottom=new Pane();
        bottom.setLayoutX(114);
        bottom.setLayoutY(502);
        bottom.setPrefWidth(336);
        bottom.setPrefHeight(2);
        bottom.setStyle("-fx-background-color:#ffffff;");
        
        /*Use Pane as A Line for Left for design with with Color With White Color*/
         Pane left=new Pane();
        left.setLayoutX(463);
        left.setLayoutY(255);
        left.setPrefWidth(1);
        left.setPrefHeight(212);
        left.setStyle("-fx-background-color:#ffffff;");
        
        /*Pane use as a Line for Above of Button Just for Disign with White Color*/
        Pane above=new Pane();
        above.setLayoutX(114);
        above.setLayoutY(250);
        above.setPrefWidth(336);
        above.setPrefHeight(2);
        above.setStyle("-fx-background-color:#ffffff;");
        
        Label base=NLabel.nLabel("Base 2 to Base 10", 45, 540, 40, 250);
        base.setFont(Font.font("Baskerville Old Face", 15));
        base.setStyle("-fx-background-color:#00FFFF");
        
        Label infor=NLabel.nLabel("Information", 30, 500, 40, 150);
        infor.setFont(Font.font("Baskerville Old Face", 20));
        infor.setTextFill(NColor.AQUA);
        
        Group pane=new Group();
        pane.getChildren().addAll(left,right,above,bottom);
        pane.setEffect(dropShadow);
        
          
          anchor.getChildren().addAll(title,stack,pane,base,infor,separter,button);
        
        return anchor;
    }
}
