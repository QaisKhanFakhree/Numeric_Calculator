/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Quinary;

import Decimal.CodeConverter.Code;
import Others.NColor;
import Tools.NButton;
import Tools.NLabel;
import Tools.NPane;
import Tools.NStackPane;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

/**
 *
 * @author Qais Khan
 */
public class QuinarytoOctal {
    private static String value="";
    public static Node AllComponent(){
        AnchorPane anchorPane=new AnchorPane();
        
        Pane separter=NPane.pane(604,3 ,0, 0);
        
        Label title=NLabel.nLabel("Converting Quinary to Octal : ",38, 37,30, 520);
        title.setTextFill(NColor.WHITE);
        title.setFont(new Font(30));
        
        StackPane stackpane=NStackPane.Stack(560,101,21, 112);
        Label lab=NLabel.nLabel("0",0,0,39,552);
        lab.setFont(Font.font("Britannic Bold",20));
        stackpane.getChildren().add(lab);
        lab.setTextFill(NColor.BLACK);
        
        Label user=NLabel.nLabel("Use Number Keybroad",119,260,40,300);
        user.setTextFill(NColor.WHITE);
        user.setFont(new Font(20));
        
        Button zero=NButton.MButton("0",119,300,"WHITE",1,100, 33);
        zero.setFont(Font.font("Baskerville Old Face",15));
        zero.setTextFill(NColor.WHITE);
        zero.setOnAction(N->{
        value=value+"0";
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button one=NButton.MButton("1",235, 300,"WHITE",1,100, 33);
        one.setFont(Font.font("Baskerville Old Face",15));
        one.setTextFill(NColor.WHITE);
        one.setOnAction(N->{
        value=value+1;
        lab.setText(value);
        lab.setTextFill(NColor.BLACK);
        });
        
        Button two=NButton.MButton("2",350,300,"WHITE",1,100,33);
        two.setFont(Font.font("Baskerville Old Face",15));
        two.setTextFill(NColor.WHITE);
        two.setOnAction(N->{
        value=value+2;
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button three=NButton.MButton("3",119,350,"WHITE",1,100, 33);
        three.setFont(Font.font("Baskerville Old Face",15));
        three.setTextFill(NColor.WHITE);
        three.setOnAction(N->{
        value=value+3;
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button four=NButton.MButton("4",235,350,"WHITE",1,100,33);
        four.setFont(Font.font("Baskerville Old Face", 15));
        four.setTextFill(NColor.WHITE);
        four.setOnAction(N->{
        value=value+4;
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button back=NButton.MButton("Back",350, 350,"WHITE",1,100,33);
        back.setFont(Font.font("Baskerville Old Face",15));
        back.setTextFill(NColor.WHITE);
        back.setOnAction(N->{
        value=value.substring(0,value.length()-1);
        lab.setTextFill(NColor.BLACK);
        lab.setText(value);
        });
        
        Button convert=NButton.MButton("Convert",160,400,"WHITE",1,230,33);
        convert.setFont(Font.font("Baskerville Old Face",15));
        convert.setTextFill(NColor.WHITE);
        convert.setOnAction(N->{
        lab.setTextFill(NColor.DARKGREEAN);
        lab.setText(Code.Convert(Code.binToDec(value,5),8));
        value="";
        });
        
        Pane right=NPane.pane(1, 212, 97, 254);
        Pane bottom=NPane.pane(336,2, 114, 502);
        Pane left=NPane.pane(1, 212, 463, 255);
        Pane above=NPane.pane(336,2, 114, 250);
     
        DropShadow dropShadow = new DropShadow();
        dropShadow.setRadius(5.0);
        dropShadow.setOffsetX(3.0);
        dropShadow.setOffsetY(3.0);
        dropShadow.setColor(NColor.BLACK); 
        
        Label base=NLabel.nLabel("Base 5 to Base 8", 45, 540, 40, 250);
        base.setFont(Font.font("Baskerville Old Face", 15));
        base.setStyle("-fx-background-color:#00FFFF");
        
        Label infor=NLabel.nLabel("Information", 30, 500, 40, 150);
        infor.setFont(Font.font("Baskerville Old Face", 20));
        infor.setTextFill(NColor.AQUA);
     
        Group Grouppane=new Group();
        Grouppane.getChildren().addAll(left,right,bottom,above);
        Grouppane.setEffect(dropShadow);
     
        Group button=new Group();
        button.getChildren().addAll(one,two,zero,three,four,back,convert);
        
        anchorPane.getChildren().addAll(separter,title,infor,base,stackpane,user,button,Grouppane);
        return anchorPane;
        
    }
}
